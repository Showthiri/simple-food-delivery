import React from 'react'
import './Homeoffer.css'
const Homeoffer = () => {
  return (
    <div className="homeofffer">
       <a href="/Offer"><div className="h1offer">
           <button><h1>OFFER <span>F00D</span> WEEKEND OFFER</h1></button>  
            </div>
            </a>
            <div className="OFFIMG">
            <div className="homeofferimg">
                <img src="https://i.pinimg.com/originals/fb/35/c5/fb35c5ada75f053b82007974513ceb19.png" alt="" />
            </div>

            <div className="homeofferimg">
                <img src="https://i.pinimg.com/originals/fb/35/c5/fb35c5ada75f053b82007974513ceb19.png" alt="" />
            </div>

            <div className="homeofferimg">
                <img src="https://i.pinimg.com/originals/fb/35/c5/fb35c5ada75f053b82007974513ceb19.png" alt="" />
            </div>
            </div>
            
    </div>
  )
}

export default Homeoffer