import React from 'react'

const Footer = () => {
  return (
    <div className='topbar-container  mt-5'style={{paddingTop:"50px"}}>
        <div className="top  bg-tertiary d-flex gap-2 flex-wrap  justify-content-center">
            <h3 className=' text-center'>For Better Experience <br /> Download Now</h3>
                <img src="https://media-assets.swiggy.com/swiggy/image/upload/fl_lossy,f_auto,q_auto/portal/m/play_store.png" alt="" height={"50px"} />
                <img src="https://media-assets.swiggy.com/swiggy/image/upload/fl_lossy,f_auto,q_auto/portal/m/play_store.png" alt="" height={"50px"} />
            </div>
        
    </div>
  )
}

export default Footer